<?php
/**
 * Created by PhpStorm.
 * User: Viktor
 * Date: 29.09.2019
 * Time: 17:50
 */

Route::group(["prefix" => "faqs"], function() {
    Route::get('/','FaqController@index')->name('faqs.index');
});